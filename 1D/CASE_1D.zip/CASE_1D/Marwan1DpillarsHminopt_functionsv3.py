import os
import math
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def draw(H_data, v_data, A, B, C, exp, run, vorm, directory):
    path = os.path.join(directory, f"plot_{run}_{vorm}.png")
    punten = 1000
    x = punten*[0]
    y = punten*[0]
    x[0] = min(v_data)
    for i in range(1,punten):
        x[i] = x[i-1]+(1.1*max(v_data)-min(v_data))/(punten-1)
        y[i] = A + B/x[i] + C*(x[i]**exp)
    plt.plot(x, y, label="Fitted Curve")
    plt.plot(v_data, H_data, '.', label="Data Points")
    ax = plt.gca()
    ax.set_ylim([0, 3 * min(H_data)])
    ax.set_xlim([0, 1.1* max(v_data)])
    plt.legend()
    plt.savefig(path)
    plt.close()

def H(v, A,B,C,exp):
    return A+B/v+C*pow(v, exp)

def setp(p, directory, filename):
    script = os.path.join(directory, filename)
    with open(script, "r") as file:
        lines = file.readlines()
    with open(script, "w") as file:
        for line in lines:
            line_list = line.split()
            if len(line_list) >= 1 and line_list[0] == 'setup1.SendCommand(Command="/define/periodic-conditions/pressure-gradient-specification?':
                line = line.replace(line_list[1], str(p))
            file.write(line)

def setpicturename(index,directory,filename):
    script = os.path.join(directory, filename)
    with open(script, "r") as file:
        lines = file.readlines()
    with open(script, "w") as file:
        for line in lines:
            line_list = line.split()
            if len(line_list) >= 1 and line_list[0] == "setup1.SendCommand(Command=r'/display/save-picture":
                line = line.replace(line_list[1], fr'C:\Users\Microdevice\Documents\Marwan\v3\vmav{index}.png'+"')")
            file.write(line)

def setc(c, directory, filename):
    script = os.path.join(directory, filename)
    with open(script, "r") as file:
        lines = file.readlines()
    with open(script, "w") as file:
        for line in lines:
            line_list = line.split()
            if len(line_list) >= 1 and line_list[0] == 'setup1.SendCommand(Command="/mesh/modify-zones/create-periodic-interface':
                line = line.replace(line_list[7], str(round(2*c*1e-6,9)))
            file.write(line)

def replace_in_file(filepath, old_word, new_word):
    with open(filepath, 'r') as file:
        file_contents = file.read()
    modified_contents = file_contents.replace(old_word, new_word)
    with open(filepath, 'w') as file:
        file.write(modified_contents)

def replace(directory, filename, old_word, new_word):
    location = os.path.join(directory, filename)
    replace_in_file(location, old_word, new_word)

def write(directory, filename, integer):
    file_path = os.path.join(directory, filename)
    with open(file_path, 'w') as file:
        file.write(str(integer))

def read(directory, filename):
    path = os.path.join(directory, filename)
    with open(path, "r") as file:
        content = file.read()
    return content

def make_excel(a, b, c, d, e, m, n, exp, C, B,A, p_data, H_data, v_data, run, index_list, vorm, directory, v_inletdata, kappa, L, N, dh, h, Pe, v_min, H2_Kv, diff):
    length = len(A)
    path = os.path.join(directory, f"run{run}.xlsx")
    new_data = {
        'index': index_list,
        'vorm': [vorm] * length,
        'a(\u00b5m)': [a] * length,
        'b(\u00b5m)': [b] * length,
        'c(\u00b5m)': [c] * length,
        'd(\u00b5m)': [d] * length,
        'e': [e] * length,
        'm': [m] * length,
        'n': [n] * length,
        'p(Pa/m)': p_data,
        'v_x,inlet(m/s)': v_inletdata,
        'v_x,av(m/s)': v_data,
        'H(m)': H_data,
        'kappa(m^2)': [kappa] * length,
        'H^2/kappa': H2_Kv,
        'A': A,
        'B': B,
        'C': C,
        'exp': exp,
        'v_x,av,min(m/s)': v_min,
        '%diff of v_min': diff,
        'L(m)': L,
        'N': N,
        'hydr. di.(\u00b5m)': [dh] * length,
        'h': h,
        'Pe': Pe,
        'D(m^2/s)': [1e-9] * length,
        'µ(Ns/m^2)': [0.001003] * length
    }
    new_df = pd.DataFrame(new_data)
    if os.path.exists(path):
        existing_df = pd.read_excel(path, engine='openpyxl')
        combined_df = pd.concat([existing_df, new_df], ignore_index=True)
    else:
        combined_df = new_df
    combined_df.to_excel(path, index=False, engine='openpyxl')

def get_value_from_file(filepath):
    with open(filepath, "r") as file:
        content = file.read().split()
    return float(content[-1])

def getv(index, directory):
    vmx_path = os.path.join(directory, f"Hydra_files/dp0/FLU-{index}/Fluent/vmx1.out")
    return get_value_from_file(vmx_path)

def getH(index, directory):
    hmicro_path = os.path.join(directory, f"Hydra_files/dp0/FLU-{index}/Fluent/hmicro-rfile.out")
    return get_value_from_file(hmicro_path)

def getvinlet(index, directory):
    vinlet_path = os.path.join(directory, f"Hydra_files/dp0/FLU-{index}/Fluent/vmxinlet.out")
    with open(vinlet_path, "r") as file:
        content = file.read().split()
    vmxi_values = [float(content[-i]) if float(content[-i]) <= 100 else 0 for i in range(1, 4)]
    return max(vmxi_values)

def omtrek(a, b, m, n):
    aantal_steps = 100000
    step_size = b / aantal_steps
    x = 0
    omtrek = 0
    for _ in range(aantal_steps):
        dydx = derivative_f(a, b, n, m, x)
        omtrek += math.sqrt(1 + pow(dydx, 2)) * step_size
        x += step_size
    return 4 * omtrek

def derivative_f(a, b, n, m, x):
    h = 1e-7
    return (fun(a, b, n, m, x + h) - fun(a, b, n, m, x)) / h

def fun(a, b, n, m, x):
    return a * pow(1 - pow((x / b), m), n)

def calculate_c(a, b, m, n, e, d):
    return oppervlakte(a, b, m, n) / ((1 - e) * d)

def make_coordinates_txt(a,b,m,n,e,d,c,directory,filename1,filename2):    
    aantal_steps = 400
    stop = b
    step =b/aantal_steps 
    while step <0.002:
        aantal_steps = aantal_steps -1  
        step =b/aantal_steps 
    x = [0]
    y = []
    for i in range(1, int(stop/step)) :
        x.append(x[i-1]+step)
    if len(x) == 100:
        x[len(x)-1] = b
    else:
        x.append(b)
        
    for el in x:
        y_el = a*pow(1-pow((el/b),m),n)
        if el != b:
            if y_el < 0.002:
                y_el = 0.002
        y.append(y_el)
    file_w = os.path.join(directory,filename1)
    w = 1
    z = 1
    diff  = []
    limiet = 0
    for i in range(0,len(x)):
        if i>=1:
            diff.append((y[i]-y[i-1])/(x[i]-x[i-1]))
        if i>=2:
            if abs((diff[i-1]-diff[i-2])/(x[i-1]-x[i-2]))>limiet:
                limiet = abs((diff[i-1]-diff[i-2])/(x[i-1]-x[i-2]))
                index = i-1
    with open(file_w, 'w') as file:
        for i in range(0,len(x)):
            file.write(f"{z}\t{w}\t{round(x[i]*1000)/1000}\t{round(y[i]*1000)/1000}\t0\n")
            w=w+1
            if i ==1 or i == index:
                z=z+1
                w= 1
                file.write(f"{z}\t{w}\t{round(x[i]*1000)/1000}\t{round(y[i]*1000)/1000}\t0\n")
                w= w+1
            if len(x)-2 == len(x)-index-1:
                if i == len(x)-2:
                    z=z+1
                    w= 1
                    file.write(f"{z}\t{w}\t{round(x[i]*1000)/1000}\t{round(y[i]*1000)/1000}\t0\n")
                    w= w+1
        z = z+1
        file.write(f"{z}\t1\t{round(x[len(x)-1]*1000)/1000}\t{round(y[len(x)-1]*1000)/1000}\t0\n")
        file.write(f"{z}\t2\t0\t0\t0\n")
        z=z+1
        file.write(f"{z}\t1\t0\t0\t0\n")
        file.write(f"{z}\t2\t{round(x[0]*1000)/1000}\t{round(y[0]*1000)/1000}\t0\n")
        w = 1
        z = z+1
        for i in range(0,len(x)):
            file.write(f"{z}\t{w}\t{round((c-x[len(x)-i-1])*1000)/1000}\t{round((d-y[len(y)-i-1])*1000)/1000}\t0\n")
            w=w+1
            if i ==len(x)-2 or i == len(x)-index-1:
                z=z+1
                w= 1
                file.write(f"{z}\t{w}\t{round((c-x[len(x)-i-1])*1000)/1000}\t{round((d-y[len(y)-i-1])*1000)/1000}\t0\n")
                w= w+1
            if len(x)-2 == len(x)-index-1:
                if i == 1:
                    z=z+1
                    w= 1
                    file.write(f"{z}\t{w}\t{round((c-x[len(x)-i-1])*1000)/1000}\t{round((d-y[len(y)-i-1])*1000)/1000}\t0\n")
                    w= w+1
        z = z+1
        w= 1
        for i in range(0,len(x)):
            file.write(f"{z}\t{w}\t{round((c+x[i])*1000)/1000}\t{round((d-y[i])*1000)/1000}\t0\n")
            w=w+1
            if i ==1 or i == index:
                z= z+1
                w= 1
                file.write(f"{z}\t{w}\t{round((c+x[i])*1000)/1000}\t{round((d-y[i])*1000)/1000}\t0\n")
                w= w+1
            if len(x)-2 == len(x)-index-1:
                if i == len(x)-2:
                    z=z+1
                    w= 1
                    file.write(f"{z}\t{w}\t{round((c+x[i])*1000)/1000}\t{round((d-y[i])*1000)/1000}\t0\n")
                    w= w+1
        z = z+1
        file.write(f"{z}\t1\t{round((c+x[len(x)-1])*1000)/1000}\t{round((d-y[len(y)-1])*1000)/1000}\t0\n")
        file.write(f"{z}\t2\t{round((c-x[len(x)-1])*1000)/1000}\t{round((d-y[len(y)-1])*1000)/1000}\t0\n")
        
        z = z+1
        w= 1
        for i in range(0,len(x)):
            file.write(f"{z}\t{w}\t{round((2*c-x[len(x)-i-1])*1000)/1000}\t{round(y[len(y)-i-1]*1000)/1000}\t0\n")
            w=w+1
            if i ==len(x)-2 or i == len(x)-index-1:
                z=z+1
                w= 1
                file.write(f"{z}\t{w}\t{round((2*c-x[len(x)-i-1])*1000)/1000}\t{round(y[len(y)-i-1]*1000)/1000}\t0\n")
                w= w+1
            if len(x)-2 == len(x)-index-1:
                if i == 1:
                    z=z+1
                    w= 1
                    file.write(f"{z}\t{w}\t{round((2*c-x[len(x)-i-1])*1000)/1000}\t{round(y[len(y)-i-1]*1000)/1000}\t0\n")
                    w= w+1
        z = z+1
        file.write(f"{z}\t1\t{round((2*c-x[len(x)-1])*1000)/1000}\t0\t0\n")
        file.write(f"{z}\t2\t{round(2*c*1000)/1000}\t{0}\t0\n")
        z = z+1
        file.write(f"{z}\t1\t{round(2*c*1000)/1000}\t{0}\t0\n")
        file.write(f"{z}\t2\t{round(2*c*1000)/1000}\t{round(y[0]*1000)/1000}\t0\n")
    file_r = os.path.join(directory,filename2)
    with open(file_r, 'w') as file:
        file.write('1\t1\t0\t0\t0\n')
        file.write('1\t2\t0\t'+str(d)+'\t0\n')
        file.write('2\t1\t0\t0\t0\n')
        file.write('2\t2\t'+str(round(2*c*1000)/1000)+'\t0\t0\n')
        file.write('3\t1\t'+str(round(2*c*1000)/1000)+'\t'+str(d)+'\t0\n')
        file.write('3\t2\t0\t+'+str(d)+'\t0\n')
        file.write('4\t1\t'+str(round(2*c*1000)/1000)+'\t0\t0\n')
        file.write('4\t2\t'+str(round(2*c*1000)/1000)+'\t'+str(d)+'\t0\n')
    with open(file_r, 'r') as file:
        file_content = file.read()
    file_content = file_content.replace('.', ',')
    with open(file_r, 'w') as file:
        file.write(file_content)
        
    with open(file_w, 'r') as file:
        file_content = file.read()
    file_content = file_content.replace('.', ',')
    with open(file_w, 'w') as file:
        file.write(file_content)

def oppervlakte(a, b, m, n):
    aantal_steps = 100000
    step_size = b / aantal_steps
    x = 0
    area = 0
    for _ in range(aantal_steps):
        area += fun(a, b, n, m, x) * step_size
        x += step_size
    return 2 * area

def run_ansys_command(command):
    os.system(command)

def calculateH():
    command = r'"C:\\Program Files\\ANSYS Inc\\v231\\Framework\\bin\\Win64\\runwb2" -B -F C:\\Users\\Microdevice\\Documents\\Marwan\\v3\\Hydra.wbpj -R C:\\Users\\Microdevice\\Documents\\Marwan\\v3\\v1final.wbjn'
    run_ansys_command(command)

def make_CFD_geometry():
    command = r'"C:\\Program Files\\ANSYS Inc\\v231\\Framework\\bin\\Win64\\runwb2" -B -F C:\\Users\\Microdevice\\Documents\\Marwan\\v3\\Hydra.wbpj -R C:\\Users\\Microdevice\\Documents\\Marwan\\v3\\v0final.wbjn'
    run_ansys_command(command)
