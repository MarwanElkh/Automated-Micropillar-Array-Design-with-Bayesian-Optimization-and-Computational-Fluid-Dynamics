from Marwan2DpillarsHminopt_functionsv4 import *
import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
from scipy.optimize import fsolve
import math

def function(x):
    print(x)
    a = round(x[0]/1000,3)
    b = round(x[1]/1000,3)
    m = 2
    d = 2
    e = 0.5
    n = 0.5
    c = math.ceil(1000*calculate_c(a,b,m,n,e,d))/1000

    directory = f"C:\\Users\\Microdevice\\Documents\\Marwan\\v4"
    filename1 = "coordinates3dcurves.txt"
    filename2 = "coordinatesrechthoeks.txt"
    filename3 = "index.txt"
    filename4 = "v1final.wbjn"
    filename5 = "v0final.wbjn"
    filename6 = "run.txt"
    filename7 = "vorm.txt"

    index = int(read(directory,filename3))
    run = int(read(directory,filename6))
    vorm = int(read(directory,filename7))

    A = [0]
    exp = [0]
    C = [0]
    B = [0]
    p_data = [0]
    H_data = [0]
    v_data = [0]
    v_inletdata = [0]
    kappa = 0
    L  = [0]
    N = [0]
    opp = 2*oppervlakte(a, b, m, n)
    om = omtrek(a, b, m, n)
    Dm = 10**-9
    dh = 4*opp/om
    h = [0]
    Pe = [0]
    v_min = [0]
    H2_Kv = [1e3]
    diff = [0]
    index_list = [0]
    down =[1e-20,1e-20,1e-20,0]
    up  = [1e-1,1e-1,1e-1,100]

    if (c > b):
        make_coordinates_txt(a,b,m,n,e,d,c,directory,filename1,filename2)
        make_CFD_geometry()
        A = 7*[0]
        B = 7*[0]
        C = 7*[0]
        exp = 7*[0]
        v_min = 7*[0]
        p_data = 7*[-100000]
        Pe = [0.01, 15, 50, 125, 0, 0, 0]
        v_data = list((Dm/(dh*10**-6))*np.array(Pe))
        H_data = 7*[0]
        v_inletdata = 7*[0]
        setc(c,directory,filename4)
        for i in range(0,7):
            if i > 3:
                param, cov = curve_fit(H, v_data [0:i], H_data[0:i],maxfev = 10000, p0=[5e-8,1e-9,5e-6,1], bounds = (down,up))
                A[i-1] = param[0]
                B[i-1] = param[1]
                C[i-1] = param[2]
                exp[i-1] = param[3]
                def dhdv(v):
                    return -B[i-1]*pow(1/v,2)+C[i-1]*exp[i-1]*v**(exp[i-1]-1)
                v_min[i-1] = fsolve(dhdv, x0=0.000002)[0]
                if i == 4:
                    v_data[i] = 3*v_min[i-1]
                if i == 5:
                    v_data[i] = v_min[i-1]/2
                if i == 6:
                    v_data[i] = v_min[i-1]
            if i >0:
                p_data[i] = p_data[i-1]*v_data[i]/v_data[i-1]
            setp(p_data[i],directory,filename4)
            setpicturename(index,directory,filename4)
            calculateH()
            v_inletdata[i] = getvinlet(index,directory)
            v_data[i] = getv(index,directory)
            H_data[i] = getH(index,directory)
            index = index+1
        param,cov = curve_fit(H, v_data[0:7], H_data[0:7],maxfev = 10000, p0=[5e-8,1e-9,5e-6,1], bounds = (down,up))
        A[6] = param[0]
        B[6] = param[1]
        C[6] = param[2]
        exp[6] = param[3]
        def dhdv(v):
            return -B[6]*pow(1/v,2)+C[6]*exp[6]*v**(exp[6]-1)
        v_min[6] = fsolve(dhdv, x0=0.000002)[0]
        µ = 0.001003
        kappa = np.sum((-np.array(p_data)/µ)*np.array(v_data)) / np.sum((-np.array(p_data)/µ)** 2)
        L = [0]*len(H_data)
        N = [0]*len(H_data)
        H2_Kv = [0]*len(H_data)
        Pe = [0]*len(H_data)
        h = [0]*len(H_data)
        diff = [0]*len(H_data)
        index_list = [0]*len(H_data)   
        for i in range(0,len(H_data)):
            L[i] = kappa*4*10**7/(v_data[i]*µ)
            N[i] = L[i]/H_data[i]
            H2_Kv[i] = H_data[i]**2/kappa
            Pe[i] = v_data[i]*(dh*10**-6)/Dm
            h[i] = H_data[i]/(dh*10**-6)
            index_list[i] = index - 7 + i
            if i > 3:
                diff[i] = 100*(v_min[i-1]-v_min[i])/v_min[i-1]
        draw(H_data,v_data,A[len(A)-1],B[len(B)-1], C[len(C)-1],exp[len(exp)-1],run,vorm,directory)
        write(directory,filename3,index)
    make_excel(a,b,c,d,e,m,n,exp,C,B,A,p_data,H_data,v_data,run,index_list,vorm,directory,v_inletdata,kappa,L,N,dh,h,Pe,v_min, H2_Kv, diff)
    write(directory,filename7,vorm+1)
    return min(H2_Kv)