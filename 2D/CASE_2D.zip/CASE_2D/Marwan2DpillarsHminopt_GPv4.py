from skopt import gp_minimize
from skopt.space import Integer
from Marwan2DpillarsHminopt_functionsv4 import *
from Marwan2DpillarsHminopt_mainv4 import *
import math

d = 2
alow = round(1000*d/math.pi)
ahigh = 1600
blow = 200
bhigh = 5000

search_space = [
    Integer(alow, ahigh, name='a'),
    Integer(blow, bhigh, name='b')
]

def track_best(res):
    print(f"Step: {len(res.x_iters)}")
    print(f"Best Value: {res.fun}")
    print(f"Best Parameters: {res.x}")
    print("-" * 30)

res = gp_minimize(
    func = function,
    dimensions = search_space,
    n_calls = 59,
    n_initial_points = 15,
    initial_point_generator = "random",
    acq_func = 'EI',
    random_state = 0,
    callback = [track_best]
)